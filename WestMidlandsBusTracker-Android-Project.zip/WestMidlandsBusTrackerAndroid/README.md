# West Midlands Bus Tracker — Android app project

This is a small native Android application shell that opens the existing tracker website in an Android WebView. It does not copy or modify the website, and it keeps the existing website interface rather than redesigning it.

## Build an APK

1. Install Android Studio on a computer with the Android SDK.
2. Open this folder in Android Studio.
3. Allow Gradle sync to download the Android Gradle Plugin and dependencies.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location (normally `app/build/outputs/apk/debug/app-debug.apk`).

## Important

- The app loads `https://west-midlands-bus-tracker.vercel.app/`.
- Internet access is required; this first version is an online app shell, not an offline copy of the tracker.
- Sign-in and data continue to use the existing website/Supabase services.
- The website is not changed by this project.
- A debug APK is suitable for testing. A signed release build is needed for wider distribution.
- Google Play Protect may show a warning for APKs installed outside Google Play; this project does not bypass Android security checks.
